from ui import App

app = App()